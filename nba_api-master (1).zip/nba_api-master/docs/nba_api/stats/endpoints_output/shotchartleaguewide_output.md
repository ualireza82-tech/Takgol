League_Wide:

| GRID_TYPE       | SHOT_ZONE_BASIC       | SHOT_ZONE_AREA        | SHOT_ZONE_RANGE   |   FGA |   FGM |   FG_PCT |
|:----------------|:----------------------|:----------------------|:------------------|------:|------:|---------:|
| League Averages | Above the Break 3     | Back Court(BC)        | Back Court Shot   |    34 |     3 |    0.088 |
| League Averages | Above the Break 3     | Center(C)             | 24+ ft.           | 16718 |  5989 |    0.358 |
| League Averages | Above the Break 3     | Left Side Center(LC)  | 24+ ft.           | 26343 |  9426 |    0.358 |
| League Averages | Above the Break 3     | Right Side Center(RC) | 24+ ft.           | 24458 |  8862 |    0.362 |
| League Averages | Backcourt             | Back Court(BC)        | Back Court Shot   |   477 |    10 |    0.021 |
| League Averages | In The Paint (Non-RA) | Center(C)             | 8-16 ft.          | 13253 |  6041 |    0.456 |
| League Averages | In The Paint (Non-RA) | Center(C)             | Less Than 8 ft.   | 27251 | 11803 |    0.433 |
| League Averages | In The Paint (Non-RA) | Left Side(L)          | 8-16 ft.          |  2415 |  1076 |    0.446 |
| League Averages | In The Paint (Non-RA) | Right Side(R)         | 8-16 ft.          |  2729 |  1179 |    0.432 |
| League Averages | Left Corner 3         | Left Side(L)          | 24+ ft.           | 12210 |  4690 |    0.384 |